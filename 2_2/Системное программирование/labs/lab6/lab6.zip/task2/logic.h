#include <stdio.h>

int randomizeDigits(int min, int max);
int printArray(int* array, int size);
void sortMassive(int* massive, int amount); 
