#include <stdio.h>

int createFile(char* filename);
void fileAppend(char* filename, int* massive, int size);
void fileRead(char* filename, int* massive, int size); 
