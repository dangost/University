#ifndef LOGIC
#define LOGIC

std::string multiplications (int N);
bool CheckExist (int first_num, int second_num, int* array, int N);

#endif
